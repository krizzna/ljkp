-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `divisi`;
CREATE TABLE `divisi` (
  `iddivisi` int(11) NOT NULL,
  `divisi` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iddivisi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mesin`;
CREATE TABLE `mesin` (
  `idmesin` int(11) NOT NULL,
  `nama_mesin` varchar(45) DEFAULT NULL,
  `biaya_mesin` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idmesin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `operator`;
CREATE TABLE `operator` (
  `idoperator` int(11) NOT NULL,
  `nama_operator` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idoperator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `proses`;
CREATE TABLE `proses` (
  `idproses` int(11) NOT NULL,
  `urutan` varchar(45) DEFAULT NULL,
  `proses` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idproses`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1,	'login',	'Login privileges, granted after account confirmation'),
(2,	'admin',	'Administrative user, has access to everything.');

DROP TABLE IF EXISTS `roles_users`;
CREATE TABLE `roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`),
  CONSTRAINT `roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `roles_users` (`user_id`, `role_id`) VALUES
(3,	1),
(9,	1);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `session_id` varchar(24) NOT NULL,
  `last_active` int(10) unsigned NOT NULL,
  `contents` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_active` (`last_active`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `spk`;
CREATE TABLE `spk` (
  `nospk` varchar(20) NOT NULL,
  `tanggal` datetime DEFAULT NULL,
  `shift` varchar(45) DEFAULT NULL,
  `mesin_idmesin` int(11) NOT NULL,
  `divisi_iddivisi` int(11) NOT NULL,
  `operator_idoperator` int(11) NOT NULL,
  PRIMARY KEY (`nospk`),
  KEY `fk_spk_mesin1_idx` (`mesin_idmesin`),
  KEY `fk_spk_divisi1_idx` (`divisi_iddivisi`),
  KEY `fk_spk_operator1_idx` (`operator_idoperator`),
  CONSTRAINT `fk_spk_divisi1` FOREIGN KEY (`divisi_iddivisi`) REFERENCES `divisi` (`iddivisi`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_spk_mesin1` FOREIGN KEY (`mesin_idmesin`) REFERENCES `mesin` (`idmesin`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_spk_operator1` FOREIGN KEY (`operator_idoperator`) REFERENCES `operator` (`idoperator`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `email`, `username`, `password`, `logins`, `last_login`) VALUES
(3,	'krizzna@localhost.local',	'krizzna',	'3da16e08c63f8efb95d5a0a67cae5c858d0484a9be052fa6ab4cdae6e9f35e2b',	24,	1430383934),
(9,	'rab@rab.lan',	'rab',	'3da16e08c63f8efb95d5a0a67cae5c858d0484a9be052fa6ab4cdae6e9f35e2b',	0,	NULL);

DROP TABLE IF EXISTS `user_tokens`;
CREATE TABLE `user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`),
  CONSTRAINT `user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2015-05-12 00:59:37
